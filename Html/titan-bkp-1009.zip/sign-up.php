<?php
$pagetitle='TITAN GLOBAL SERVICES LTD';
$keywords='';
$description='';
include_once 'include/header.php';
?> 

<div class="inner-top-section">
<div class="container">
    <div class="row" data-aos="fade-left">
    <div class="col-md-5 inner-content">
        <h3> SIGNUP</h3>
        </div>
    </div>
    </div>
</div>
 
    <section id="contact" class="contact" data-aos="fade-up">
      <div class="container">
        <div class="row justify-content-center aos-init aos-animate" data-aos="fade-up">
          <div class="col-lg-12">
            <form action="#" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-4 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Contact Name" required="">
                </div>
                  <div class="col-md-4 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Company Name" required="">
                </div>
                  <div class="col-md-4 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Website" required="">
                </div>
                  <div class="col-md-4 form-group">
                  <input type="number" name="name" class="form-control" id="name" placeholder="Phone Number" required="">
                </div>
                <div class="col-md-4 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Email Address" required="">
                </div>
                  <div class="col-md-4 form-group mt-3 mt-md-0">
                  <select class="form-select" aria-label="Default select example">
  <option selected>Select Our Service Offers</option>
  <option value="Bronze">Bronze (£395)</option>
  <option value="Silver">Silver (£695)</option>
  <option value="Gold">Gold (£895)</option>
  <option value="Platinum">Platinum (£1295)</option>
</select>
                </div>
                <style>
                    .form-select
                    {
                        padding:15px!important;
                    }
                </style>
            
              </div>
             
              <div class="text-center text-right"><button type="submit">Submit Now</button></div>
            </form>
          </div>

        </div>

      </div>
    </section>


<?php
include_once 'include/footer.php';
?>