<?php
$pagetitle='TITAN GLOBAL SERVICES LTD';
$keywords='';
$description='';
include_once 'include/header.php';
?> 

<div class="inner-top-section">
<div class="container">
    <div class="row" data-aos="fade-left">
    <div class="col-md-5 inner-content">
        <h3>Our Service Offers</h3>
        <p>Following are the options for you</p>
        </div>
    </div>
    </div>
</div>
<style>
.table td th
{
    border:2px solid #ddd!important;
}
    .table th
    {
        text-align: center;
    background-color: #2da0db;
    color: #fff;
    letter-spacing: 0.3px;
    }
    .table td
    {
        padding:12px;
    }
</style>
 
    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">
        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 para-about">
              <table class="table table-bordered w-100">
  <thead>
    <tr>
      <th scope="col">Bronze</th>
      <th scope="col">Silver</th>
      <th scope="col">Gold </th>
      <th scope="col">Platinum</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Fixed price £395 </td>
      <td>First Year £695 Subsequent years 495</td>
      <td>First Year £895 Subsequent years 695 </td>
      <td>First Year £1295 Subsequent years 995
</td>
    </tr>
    <tr>
        <td>Access to online tool for generation of a simple Carbon Reduction Plan for a business.  </td>
        <td>Access to online tool for generation of a detailed Carbon Reduction Plan for your business</td>
        <td>Access to online tool for generation of a detailed Carbon Reduction Plan for your business with offsetting guidance and assistance for offsetting emissions.</td>
        <td>Access to online tool for generation of a detailed Carbon Reduction Plan for your business with offsetting guidance and assistance with offsetting emissions plus review and guidance of environmental policies and advice on social value projects. </td>
    </tr>
    <tr>
        <td>One 60 minute on-line consultation session included</td>
        <td>Two 60 minute on-line consultations sessions included</td>
        <td>Four 60 minute on-line consultations sessions included</td>
        <td>Six 60 minute on-line consultations sessions included</td>
    </tr>
    
    <tr>
        <td>Fully compliant with UK reporting regulations and government guidance on carbon reduction planning</td>
        <td>Fully compliant with UK reporting regulations and government guidance on carbon reduction planning</td>
        <td>Fully compliant with UK reporting regulations and government guidance on carbon reduction planning.</td>
        <td>Fully compliant with UK reporting regulations and government guidance on carbon reduction planning</td>
    </tr>
    
  </tbody>
</table>
          </div>
        </div>
      </div>
    </section><!-- End Portfolio Section -->


<?php
include_once 'include/footer.php';
?>