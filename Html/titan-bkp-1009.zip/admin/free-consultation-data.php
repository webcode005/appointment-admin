<?php
$pagetitle = 'Tital Global Services Ltd';
$description='';
$keywords = '';
include 'include/header.php';
?>
            <div id="layoutSidenav_content">
                <main>
                    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
                        <div class="container">
                            <div class="page-header-content pt-4">
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container mt-n10">
                        <!-- Example Colored Cards for Dashboard Demo-->
                       
                            <div class="card mb-4">
                            <div class="card-header">Free Consultation Data</div>
                                
                            <div class="card-body detail-client">
                                <div class="add-packages">
                                    <a href="dashboard.php"><button class="btn pull-right btn-primary" type="button">Go Back</button></a>
                                    <br>
                                    <br>
                                </div>
                                <div class="row">
                                <div class="col-md-6">
                                    <p><b>Client Basic Detail</b></p>
                                    <hr>
                                    <p><b>Contact Name:</b> Mohammad Kaleem</p>
                                    <p><b>Company Name:</b> ABC Private Limited</p>
                                    <p><b>Website:</b> www.abcprivatelimited.com</p>
                                    <p><b>Phone No:</b> 0998764611</p>
                                    <p><b>Email Id:</b> mohammadkaleem@gmail.com</p>
                                    
                                    </div>
                                    <div class="col-md-6">
                                    <p><b>Preferable Contact Time</b></p>
                                        <hr>
                                    <p><b>Date:</b> 12/09/2023</p>
                                    <p><b>Time</b> 9:30 - 10:00 AM</p>
                                    </div>
                                    
                                    <div class="col-md-12 border-main">
                                    <p><b>How can we help us?</b></p>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                                    </div>
                                </div>
                            </div>
                            </div>
                    </div>
                </main>
                <?php
include 'include/footer.php';
?>