<?php
$pagetitle = 'Tital Global Services Ltd - Change Password';
$description='';
$keywords = '';
include 'include/header.php';
?>
            <div id="layoutSidenav_content">
                <main>
                    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
                        <div class="container">
                            <div class="page-header-content pt-4">
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container mt-n10">
                        <!-- Example Colored Cards for Dashboard Demo-->
                       
                            <div class="card mb-4">
                            <div class="card-header">Change Password</div>
                                
                            <div class="card-body">
                                <div class="add-packages">
                                <form class="row">
                                    
                                    <div class="col-md-6">
                                    <div class="form-group">
                                    <input class="form-control" id="inputFirstName" type="text" placeholder="Old Password">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                    <input class="form-control" id="inputFirstName" type="text" placeholder="New Password">
                                    </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                    <div class="form-group">
                                    <input class="form-control" id="inputFirstName" type="text" placeholder="Re Enter New Password">
                                    </div>
                                    </div>
                                    
                                    <!-- Save changes button-->
                                    <div class="col-md-12">
                                            <button class="btn btn-primary" type="button">Submit</button>
                                    </div>
                                        </form>
                                </div>
                                
                                
                                
                            </div>
                            </div>
                    </div>
                </main>
                <?php
include 'include/footer.php';
?>