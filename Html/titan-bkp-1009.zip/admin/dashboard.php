<?php
$pagetitle = 'Tital Global Services Ltd';
$description='';
$keywords = '';
include 'include/header.php';
?>
            <div id="layoutSidenav_content">
                <main>
                    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
                        <div class="container">
                            <div class="page-header-content pt-4">
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container mt-n10">
                        <!-- Example Colored Cards for Dashboard Demo-->
                       
                            <div class="card mb-4">
                            <div class="card-header">Free Consultation Data</div>
                                
                            <div class="card-body">
                                
                                <div class="datatable">
                                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Name</th>
                                                <th>Company Name</th>
                                                <th>Phone</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                        </thead>
                                        
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>Mohammad Kaleem</td>
                                                <td>ABC Private limited</td>
                                                <td>9876543210</td>
                                                <td>12/09/2023</td>
                                                <td>9:30 - 10:00 AM</td>
                                                <td>
                                                
                                                    <a href="free-consultation-data.php"><button class="btn btn-datatable btn-icon btn-transparent-dark"><i data-feather="eye"></i></button></a>
                                                    
                                                    <a href="#"><button class="btn btn-datatable btn-icon btn-transparent-dark"><i data-feather="trash-2"></i></button></a>
                                                    
                                                </td>
                                                
                                            </tr>
                                            
                                            <tr>
                                                <td>2</td>
                                                <td>Mohammad Kaleem</td>
                                                <td>ABC Private limited</td>
                                                <td>9876543210</td>
                                                <td>12/09/2023</td>
                                                <td>9:30 - 10:00 AM</td>
                                                <td>
                                                
                                                    <a href="free-consultation-data.php"><button class="btn btn-datatable btn-icon btn-transparent-dark"><i data-feather="eye"></i></button></a>
                                                    
                                                    <a href="#"><button class="btn btn-datatable btn-icon btn-transparent-dark"><i data-feather="trash-2"></i></button></a>
                                                    
                                                </td>
                                                
                                            </tr>
                                            
                                            <tr>
                                                <td>3</td>
                                                <td>Mohammad Kaleem</td>
                                                <td>ABC Private limited</td>
                                                <td>9876543210</td>
                                                <td>12/09/2023</td>
                                                <td>9:30 - 10:00 AM</td>
                                                <td>
                                                
                                                    <a href="free-consultation-data.php"><button class="btn btn-datatable btn-icon btn-transparent-dark"><i data-feather="eye"></i></button></a>
                                                    
                                                    <a href="#"><button class="btn btn-datatable btn-icon btn-transparent-dark"><i data-feather="trash-2"></i></button></a>
                                                    
                                                </td>
                                                
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            </div>
                    </div>
                </main>
                <?php
include 'include/footer.php';
?>