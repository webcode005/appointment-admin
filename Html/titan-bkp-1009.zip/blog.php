<?php
$pagetitle='TITAN GLOBAL SERVICES LTD';
$keywords='';
$description='';
include_once 'include/header.php';
?> 

<div class="inner-top-section">
<div class="container">
    <div class="row" data-aos="fade-left">
    <div class="col-md-5 inner-content">
        <h3> Blogs</h3>
        </div>
    </div>
    </div>
</div>
 
    <section id="contact" class="contact" data-aos="fade-up">
      <div class="container">
        <div class="row aos-init aos-animate" data-aos="fade-up">
          <div class="col-lg-4">
            <div class="box-main-blog">
              <img src="main-images/slider/slider-1.jpg">
                <div class="content-blog">
                <h3>Blog Heading Title</h3>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <div class="blog-read">
                <a href="#">Read More</a>
                    </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
            <div class="box-main-blog">
              <img src="main-images/slider/slider-2.jpg">
                <div class="content-blog">
                <h3>Blog Heading Title</h3>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <div class="blog-read">
                <a href="#">Read More</a>
                    </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
            <div class="box-main-blog">
              <img src="main-images/slider/slider-3.jpg">
                <div class="content-blog">
                <h3>Blog Heading Title</h3>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <div class="blog-read">
                <a href="#">Read More</a>
                    </div>
                </div>
              </div>
            </div>
        </div>

      </div>
    </section>


<?php
include_once 'include/footer.php';
?>