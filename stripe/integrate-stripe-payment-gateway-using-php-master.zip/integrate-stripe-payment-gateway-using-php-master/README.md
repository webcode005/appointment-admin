# Instructions
Learn how to Integrate Stripe Payment Gateway using PHP
1. Download Stripe Payment Gateway Integration using PHP
2. Import Stripe PHP SDK using composer
3. Create Table in DB
4. Create your account on Stripe and get Stripe API and Publishable Keys
5. Update them in config.php
6. Test the application

All step by step guide and information is available on the [tutorial link](https://www.allphptricks.com/integrate-stripe-payment-gateway-using-php/). 
