<?php 
/*
Author: Javed Ur Rehman
Website: https://www.allphptricks.com
*/
//Stripe Credentials Configuration
define("STRIPE_SECRET_API_KEY", "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");
define("STRIPE_PUBLISHABLE_KEY", "pk_live_51Ng2BqKf4SeJUQvXiqbkgP6VsdN3UyYuBheTcOdTxmcPPh2zZoL71SNLUJyVOp6kMzScV7PB680it8ng9ZtLR2GR00DJFq9eCU");

//Sample Product Details
define('CURRENCY', 'USD');
define('AMOUNT', '10');
define('DESCRIPTION', 'Laptop Bag');

// Database Credentials Configuration 
define('DB_HOST', 'localhost');
define('DB_NAME', 'stripe');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
?>